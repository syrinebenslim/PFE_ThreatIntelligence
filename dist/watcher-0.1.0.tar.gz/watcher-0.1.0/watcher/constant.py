ASN_REGEX_PATTERN = r"-([a-z0-9_]+)-tunisia"
DATE_REGEX_PATTERN = r"^(\d{4}-\d{2}-\d{2})"
FULL_SHADOW_REGEX_PATTERN =r"^(\d{4}-\d{2}-\d{2})-([a-z0-9_]+)-tunisia"
